module.exports = ({ addBase }) => {
  addBase({
    // types of text element
    // can be applied to any heading or paragraph as our styles have been reset for those

    ".title-1": {
      "@apply font-bold text-xl leading-snug": "",
      "@screen md": {
        "&": {
          "@apply font-normal text-3xl leading-close": ""
        }
      }
    },

    ".title-2": {
      "@apply text-xl leading-snug": "",
      "@screen md": {
        "&": {
          "@apply text-2xl leading-normal": ""
        }
      }
    },

    ".subtitle-1": {
      "@apply text-lg leading-relaxed": "",
      "@screen md": {
        "&": {
          "@apply text-xl leading-snug": ""
        }
      }
    },

    ".subtitle-2": {
      "@apply text-base leading-normal": "",
      "@screen md": {
        "&": {
          "@apply text-lg leading-relaxed": ""
        }
      }
    },

    ".body-2": {
      "@apply text-sm leading-loose": "",

      "@screen md": {
        "&": {
          "@apply text-base leading-normal": ""
        }
      }
    },

    ".note": {
      "@apply text-sm leading-loose": ""
    }
  });
};
