module.exports = ({ addBase }) => {
  addBase({
    "@font-face": [
      {
        fontFamily: '"JustScript"',
        fontWeight: "normal",
        src: `url("./fonts/JustScriptWeb-Regular.woff2") format("woff2"),
          url("./fonts/JustScriptWeb-Regular.woff") format("woff")`
      },
      {
        fontFamily: '"JustSans"',
        fontWeight: "normal",
        src: `url("./fonts/JustSansWeb-Regular.woff2") format("woff2"),
          url("./fonts/JustScriptWeb-Regular.woff") format("woff")`
      },
      {
        fontFamily: '"JustSans"',
        fontWeight: "bold",
        src: `url("./fonts/JustSansWeb-Bold.woff2") format("woff2"),
          url("./fonts/JustSansWeb-Bold.woff") format("woff")`
      }
    ]
  });
};
