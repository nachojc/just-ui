module.exports = ({ addBase }) => {
  addBase({
    html: {
      "@apply font-just-sans text-just-black leading-normal": ""
    }
  });
};
