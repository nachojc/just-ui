module.exports = ({ addUtilities }) => {
  addUtilities({
    ".flex-basis-auto": {
      "flex-basis": "auto"
    },
    ".u-centered": {
      position: "absolute",
      left: "50%",
      top: "50%",
      transform: "translate(-50%, -50%)"
    }
  });
};
