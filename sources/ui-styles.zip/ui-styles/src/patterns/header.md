---
title: Header
---

## Example

<header class="border-b border-just-black-12 bg-white">
  <div class="container -mb-px">
    <div class="columns py-5 md:py-6">
      <div class="column w-1/4 md:w-1/6">
        <span class="icn icn-just h-6 md:h-8 bg-left block" />
      </div>
    </div>
  </div>
</header>

### Code

```html
<header class="border-b border-just-black-12">
  <div class="container -mb-px">
    <div class="columns py-5 md:py-6">
      <div class="column w-1/4 md:w-1/6">
        <span class="icn icn-just h-6 md:h-8 bg-left block" />
      </div>
    </div>
  </div>
</header>
```
