---
title: Modal
---

### Modal

<div class="modal-container">
    <div class="image-box"></div>
    <p class="model-text-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    <p class="model-text-2">Phasellus ultrices scelerisque metus, at pellentesque elit tristique sit amet.</p>
    <button class="jui-btn btn-modal">Call To Action</button>
</div>

#### Code

```html
<div class="modal-container">
  <div class="image-box"></div>
  <p class="model-text-1">
    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
  </p>
  <p class="model-text-2">
    Phasellus ultrices scelerisque metus, at pellentesque elit tristique sit
    amet.
  </p>
  <button class="jui-btn btn-modal">Call To Action</button>
</div>
```
