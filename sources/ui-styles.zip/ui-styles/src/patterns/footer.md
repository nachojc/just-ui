---
title: Footer
---

## Default

<footer class="border-t border-just-black-12 flex-none text-sm leading-loose bg-white">
  <div class="container py-8 md:py-12">
    <div class="columns">
      <div class="column w-full">
        © 2018 Just Group plc
      </div>
    </div>
  </div>
</footer>

```html
<footer class="border-t border-just-black-12 flex-none text-sm leading-loose">
  <div class="container py-8 md:py-12">
    <div class="columns">
      <div class="column w-full">
        © 2018 Just Group plc
      </div>
    </div>
  </div>
</footer>
```

### Code

## Footer with Links

<footer class="border-t border-just-black-12 flex-none text-sm leading-loose">
  <div class="container py-8 md:py-12">
    <div class="columns">
      <div class="column w-full">
        © 2018 Just Group plc
      </div>
    </div>
    <div class="columns pt-4 md:pt-6">
      <div class="column w-full flex flex-col md:flex-row">
        <a class="link pb-4 md:pb-0" href=#>Privacy Policy</a>
        <span class="md:bg-just-black-12 w-px md:mx-4"></span>
        <a class="link pb-4 md:pb-0" href="#">Terms & Conditions</a>
        <span class="md:bg-just-black-12 w-px md:mx-4"></span>
        <a class="link" href="#">Cookie policy</a>
      </div>
    </div>
  </div>
</footer>

### Code

```html
<footer class="border-t border-just-black-12 flex-none text-sm leading-loose">
  <div class="container py-8 md:py-12">
    <div class="columns">
      <div class="column w-full">
        © 2018 Just Group plc
      </div>
    </div>
    <div class="columns">
      <div class="column w-full flex flex-col md:flex-row">
        <a class="link pb-4 md:pb-0" href="#">Privacy Policy</a>
        <span class="md:bg-just-black-12 w-px md:mx-4"></span>
        <a class="link pb-4 md:pb-0" href="#">Terms & Conditions</a>
        <span class="md:bg-just-black-12 w-px md:mx-4"></span>
        <a class="link" href="#">Cookie policy</a>
      </div>
    </div>
  </div>
</footer>
```
