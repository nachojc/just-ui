﻿const selectorParser = require("postcss-selector-parser");

module.exports = function({ addVariant }) {
  addVariant("group-open", ({ modifySelectors, separator }) => {
    return modifySelectors(({ selector }) => {
      return selectorParser(selectors => {
        selectors.walkClasses(sel => {
          sel.value = `group-open${separator}${sel.value}`;
          sel.parent.insertBefore(
            sel,
            selectorParser().astSync(".group\\:open ")
          );
        });
      }).processSync(selector);
    });
  });
};
