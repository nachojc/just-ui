const Color = require("color");

module.exports = ({ addComponents, theme }) => {
  addComponents({
    ".button": {
      "@apply py-3 px-4 text-sm font-bold inline-block rounded text-center": "",
      "@apply uppercase cursor-pointer text-white bg-coral border-0 no-underline leading-loose":
        "",

      "@screen md": {
        "&": {
          "@apply py-4": ""
        }
      },
      "letter-spacing": "0.075rem",
      "box-shadow": "inset 0 -3px 0 0 rgba(55, 52, 51, 0.32)",

      "&:hover, &&--hover": {
        background: Color(theme("colors.coral"))
          .lighten("0.2")
          .hex()
      },
      "&:disabled, &&--disabled": {
        "@apply opacity-32 pointer-events-none": ""
      },
      "&:active, &&--active": {
        background: Color(theme("colors.coral"))
          .mix(Color(theme("colors.just-black")), 0.2)
          .hex(),
        "@apply shadow-none": ""
      },

      // Outlined button
      "&--outlined": {
        "@apply border border-just-black-20 text-coral-dark bg-transparent shadow-none":
          ""
      },

      "&--outlined:hover, &--outlined&--hover": {
        "@apply border-just-black-64 bg-transparent": ""
      },

      "&--outlined:active, &--outlined&--active": {
        "@apply border border-just-black-20 bg-just-black-12": ""
      },

      // Text button
      "&--text": {
        "@apply text-coral-dark bg-transparent shadow-none": ""
      },

      "&--text:hover, &--text&--hover": {
        "@apply bg-transparent": ""
      },

      "&--text:active, &--text&--active": {
        "@apply bg-just-black-12 border-0": ""
      },

      "&--dark&--outlined": {
        "@apply border-white-64 text-white": ""
      },

      "&--dark&--outlined:hover, &--dark&--outlined&--hover": {
        "@apply border-white": ""
      },

      "&--dark&--outlined:active, &--dark&--outlined&--active": {
        "@apply border-white-64 bg-white-12": ""
      },

      "&--dark&--text": {
        "@apply text-white": ""
      },

      "&--dark&--text:active, &--dark&--text&--active": {
        "@apply bg-white-12": ""
      }
    }
  });
};
