---
title: "Radio"
---

## Active

<div class="radio">
    <input type="radio" id="test1" name="radio-group">
    <label for="test1">Radio Label</label>
</div>

### Code

```html
<div class="radio">
  <input type="radio" id="test1" name="radio-group" />
  <label for="test1">Radio Label</label>
</div>
```

## Hover

<div class="radio">
    <input type="radio" id="test2" class="hover" name="radio-group">
    <label for="test2">Radio Label</label>
</div>

### Code

```html
<div class="radio">
  <input type="radio" id="test2" name="radio-group" />
  <label for="test2">Radio Label</label>
</div>
```

## Checked

<div class="radio">
    <input type="radio" checked id="test3" name="radio-group_checked">
    <label for="test3">Radio Label</label>
</div>

### Code

```html
<div class="radio">
  <input type="radio" id="test3" name="radio-group" />
  <label for="test3">Radio Label</label>
</div>
```

## Disabled

<div class="radio">
    <input type="radio" disabled id="test4" name="radio-group">
    <label for="test4">Radio Label</label>
</div>

### Code

```html
<div class="radio">
  <input type="radio" id="test4" name="radio-group" />
  <label for="test4">Radio Label</label>
</div>
```

## Error

<div class="radio radio--error">
    <input type="radio" id="test-error" name="radio-group">
    <label for="test-error">Radio Label</label>
</div>

### Code

```html
<div class="radio radio--error">
  <input type="radio" id="test-error" name="radio-group" />
  <label for="test-error">Radio Label</label>
</div>
```

## Focus

### Same as browser tab defaults

## Form group

<form>
<div class="radio">
    <input type="radio" id="test5" name="radio-group">
    <label for="test5">Radio Label</label>
</div>
<div class="radio">
    <input type="radio" id="test6" name="radio-group">
    <label for="test6">Radio Label</label>
</div>
<div class="radio">
    <input type="radio" id="test7" name="radio-group">
    <label for="test7">Radio Label</label>
</div>
<div class="radio">
    <input type="radio" id="test8" name="radio-group">
    <label for="test8">Radio Label</label>
</div>
</form>
