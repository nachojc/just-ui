---
title: "Dropdown"
---

### Default

<label>Choose a Plan:</label>

<select class="dropdown">
    <option value=""></option>
    <option value="dog">FPP</option>
    <option value="cat">Aviva</option>
    <option value="hamster">Just</option>
    <option value="parrot">Wayne Enterprises</option>
    <option value="spider">Luthorcorp</option>
    <option value="goldfish">Queen Inc.</option>
</select>

### Code

```html
<label>Choose a Plan:</label>

<select class="dropdown">
  <option value=""></option>
  <option value="dog">FPP</option>
  <option value="cat">Aviva</option>
  <option value="hamster">Just</option>
  <option value="parrot">Wayne Enterprises</option>
  <option value="spider">Luthorcorp</option>
  <option value="goldfish">Queen Inc.</option>
</select>
```

### Activated

<label>Choose a Plan:</label>

<select class="dropdown dropdown--active">
    <option value=""></option>
    <option value="dog">FPP</option>
    <option value="cat">Aviva</option>
    <option value="hamster">Just</option>
    <option value="parrot">Wayne Enterprises</option>
    <option value="spider">Luthorcorp</option>
    <option value="goldfish">Queen Inc.</option>
</select>

```html
<label>Choose a Plan:</label>

<select class="dropdown dropdown--active">
  <option value=""></option>
  <option value="dog">FPP</option>
  <option value="cat">Aviva</option>
  <option value="hamster">Just</option>
  <option value="parrot">Wayne Enterprises</option>
  <option value="spider">Luthorcorp</option>
  <option value="goldfish">Queen Inc.</option>
</select>
```

### Hover

<label>Choose a Plan:</label>

<select class="dropdown dropdown--hover">
    <option value=""></option>
    <option value="dog">FPP</option>
    <option value="cat">Aviva</option>
    <option value="hamster">Just</option>
    <option value="parrot">Wayne Enterprises</option>
    <option value="spider">Luthorcorp</option>
    <option value="goldfish">Queen Inc.</option>
</select>

```html
<label>Choose a Plan:</label>

<select class="dropdown dropdown--hover">
  <option value=""></option>
  <option value="dog">FPP</option>
  <option value="cat">Aviva</option>
  <option value="hamster">Just</option>
  <option value="parrot">Wayne Enterprises</option>
  <option value="spider">Luthorcorp</option>
  <option value="goldfish">Queen Inc.</option>
</select>
```

### Error

<label>Choose a Plan:</label>

<select class="dropdown dropdown--error">
    <option value=""></option>
    <option value="dog">FPP</option>
    <option value="cat">Aviva</option>
    <option value="hamster">Just</option>
    <option value="parrot">Wayne Enterprises</option>
    <option value="spider">Luthorcorp</option>
    <option value="goldfish">Queen Inc.</option>
</select>
<span class="input-message input-message--error">Inline error message</span>

```html
<label>Choose a Plan:</label>

<select class="dropdown dropdown--error">
  <option value=""></option>
  <option value="dog">FPP</option>
  <option value="cat">Aviva</option>
  <option value="hamster">Just</option>
  <option value="parrot">Wayne Enterprises</option>
  <option value="spider">Luthorcorp</option>
  <option value="goldfish">Queen Inc.</option>
</select>
<span class="input-message input-message--error">Inline error message</span>
```

### Disabled

<label>Choose a Plan:</label>

<select class="dropdown" disabled>
    <option value=""></option>
    <option value="dog">FPP</option>
    <option value="cat">Aviva</option>
    <option value="hamster">Just</option>
    <option value="parrot">Wayne Enterprises</option>
    <option value="spider">Luthorcorp</option>
    <option value="goldfish">Queen Inc.</option>
</select>

```html
<label>Choose a Plan:</label>

<select class="dropdown" disabled>
  <option value=""></option>
  <option value="dog">FPP</option>
  <option value="cat">Aviva</option>
  <option value="hamster">Just</option>
  <option value="parrot">Wayne Enterprises</option>
  <option value="spider">Luthorcorp</option>
  <option value="goldfish">Queen Inc.</option>
</select>
```
