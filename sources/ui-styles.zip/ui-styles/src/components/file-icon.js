module.exports = ({ addComponents }) => {
  addComponents({
    ".line": {
      stroke: "#b5b8ba",
      "stroke-linecap": "round"
    },

    ".rect": {
      fill: "#b5b8ba"
    },

    ".file-type-text": {
      "font-size": "8px",
      "letter-spacing": "0.08em",
      "font-weight": "bold",
      fill: "white"
    }
  });
};
