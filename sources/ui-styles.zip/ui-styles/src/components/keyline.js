module.exports = ({ addComponents }) => {
  addComponents({
    ".keyline": {
      "@apply block h-px bg-just-black-12 border-0": ""
    }
  });
};
