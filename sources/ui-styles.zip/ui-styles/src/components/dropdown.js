module.exports = ({ addComponents }) => {
  addComponents({
    ".dropdown": {
      background: `url("data:image/svg+xml;base64,77u/PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij4NCiAgICA8ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPg0KICAgICAgICA8cGF0aCBmaWxsPSIjMzczNDMzIiBkPSJNNyAxMGw1IDUgNS01eiIvPg0KICAgICAgICA8cGF0aCBkPSJNMCAwaDI0djI0SDB6Ii8+DQogICAgPC9nPg0KPC9zdmc+DQo=") no-repeat right 1rem center`,
      "@apply pl-4 pr-8 py-3 leading-normal rounded w-full border border-just-black-20 border-solid bg-white rounded appearance-none":
        "",

      "&:hover, &&--hover": {
        "@apply border-just-black-64": ""
      },

      "&:disabled, &&--disabled": {
        "@apply opacity-32 pointer-events-none": ""
      },
      "&&--readonly": {
        "@apply opacity-64 pointer-events-none": ""
      },

      "&:active, &&--active, &:focus, &&--focus": {
        "@apply border-skyan": ""
      },
      "&&--error": {
        "@apply border-tangerine": ""
      }
    }
  });
};
