---
title: "Link"
---

## Default

<a class="link" href="">Link</a>
<a class="link link--active" href="">Active state</a>

### Code

```html
<a class="link" href="">Link</a> <a class="link" href="">Active</a>
```

## No underline

<a class="link link--no-underline" href="">Link no underline</a>
<a class="link link--no-underline link--active" href="">Active</a>

### Code

```html
<a class="link link--no-underline" href="">Link no underline</a>
<a class="link link--no-underline link--active" href="">Active</a>
```

## Link in paragraph

<p>
Lorem ipsum <a class="link" href="">link in paragraph</a> lorum ipsum sit dolar ipsum
</p>

### Code

```html
<p>
  Lorem ipsum <a class="link" href="">link in paragraph</a> lorum ipsum sit
  dolar ipsum
</p>
```

## Link in paragraph no underline

<p>
Lorem ipsum <a class="link link--no-underline" href="">link in paragraph</a> lorum ipsum
 lorum ipsum sit dolar ipsum
</p>

### Code

```html
<p>
  Lorem ipsum
  <a class="link link--no-underline" href="">link in paragraph</a> lorum ipsum
  sit dolar ipsum
</p>
```
