module.exports = ({ addComponents }) => {
  const arrowWidth = "1.3rem";
  const arrowHeight = "1.3rem";
  const shadowSize = "0.6rem";
  const shadowColor = "rgba(34, 36, 38, 0.32)";
  addComponents({
    ".popover-container": {
      "border-radius": "0.25rem",
      background: "#fff",
      "box-sizing": "border-box",
      width: "16.75rem",
      "box-shadow": `0 0 0.5rem 0 ${shadowColor}`,
      "@apply outline-none z-50": ""
    },
    ".popover-arrow": {
      position: "absolute",
      "box-sizing": "border-box",
      "&::before": {
        content: '""',
        position: "absolute",
        width: arrowWidth,
        height: arrowHeight,
        "box-sizing": "border-box",
        background: "#fff",
        "box-shadow": `0 0 ${shadowSize} ${shadowColor}`,
        "clip-path": `polygon(calc(${shadowSize} * -1) calc(${shadowSize} * -1),
        calc(100% + ${shadowSize}) calc(${shadowSize} * -1),
         calc(100% + ${shadowSize}) calc(100% + ${shadowSize}))`
      },
      '&[data-placement*="top"]': {
        bottom: 0,
        left: 0,
        "&::before": {
          transform: "translate(51%, -51%) rotate(-225deg)",
          right: 0
        }
      },
      '&[data-placement*="bottom"]': {
        top: 0,
        left: 0,
        "&::before": {
          transform: "translate(49%, -49%) rotate(-45deg)",
          right: 0
        }
      },
      '&[data-placement*="left"]': {
        right: 0,
        "&::before": {
          transform: "translate(50%, -50%) rotate(45deg)",
          right: 0
        }
      },
      '&[data-placement*="right"]': {
        left: 0,
        "&::before": {
          transform: "translate(50%, -50%) rotate(-135deg)",
          right: 0
        }
      },
      '&[data-placement*="top-start"], &[data-placement*="bottom-start"]': {
        "&::before": {
          right: `calc(2 * ${arrowWidth})`
        }
      },
      '&[data-placement*="top-end"], &[data-placement*="bottom-end"]': {
        "&::before": {
          right: `calc(-2 * ${arrowWidth})`
        }
      },
      '&[data-placement*="left-start"], &[data-placement*="right-start"]': {
        "&::before": {
          top: `calc(-2 * ${arrowWidth})`
        }
      },
      '&[data-placement*="left-end"], &[data-placement*="right-end"]': {
        "&::before": {
          top: `calc(2 * ${arrowWidth})`
        }
      }
    }
  });
};
