---
title: "Input"
---

## Default

<label class="label">Label</label>
<input class="input" placeholder="Hint text" type="text">

### Code

```html
<label class="label">Label</label>
<input class="input" placeholder="Hint text" type="text" />
```

## Activated

<label class="label">Label</label>
<input class="input input--active" placeholder="Hint text" type="text">

### Code

```html
<label class="label">Label</label>
<input class="input input--active" placeholder="Hint text" type="text" />
```

## Hover

<label class="label">Label</label>
<input class="input input--hover" placeholder="Hint text" type="text">

### Code

```html
<label class="label">Label</label>
<input class="input input--hover" placeholder="Hint text" type="text" />
```

## Error

<label class="label">Label</label>
<input class="input input--error" placeholder="Hint text" type="text">
<span class="input-message input-message--error">Inline error message</span>

### Code

```html
<label class="label">Label</label>
<input class="input input--error" placeholder="Hint text" type="text" />
<span class="input-message input-message--error">Inline error message</span>
```

## Disabled

<label class="label">Label</label>
<input class="input" disabled placeholder="Hint text" type="text">

### Code

```html
<label class="label">Label</label>
<input class="input" disabled placeholder="Hint text" type="text" />
```

## Email

<label class="label">Label</label>
<input class="input" placeholder="Hint text" type="email">

### Code

```html
<label class="label">Label</label>
<input class="input" placeholder="Hint text" type="email" />
```
