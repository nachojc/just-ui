module.exports = ({ addComponents }) => {
  addComponents({
    ".table": {
      "border-collapse": "collapse",
      "border-style": "hidden",
      "& th, td": {
        border: "1px solid rgb(230, 230, 230)"
      }
    },

    ".item": {
      background: "white",
      "&:hover": {
        background: "#e7e6e6",
        cursor: "pointer"
      },
      "&:hover td": {
        border: "1px solid rgb(210, 210, 210)"
      }
    }
  });
};
