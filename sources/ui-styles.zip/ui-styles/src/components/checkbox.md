---
title: "Checkbox"
---

## Active

<div class="checkbox">
    <input type="checkbox" id="checkbox_1">
    <label for="checkbox_1">
      Checkbox Label
    </label>
</div>

### Code

```html
<div class="checkbox">
  <input type="checkbox" id="checkbox_1" />
  <label for="checkbox_1">
    Checkbox Label
  </label>
</div>
```

## Hover

<div class="checkbox checkbox--hover">
    <input type="checkbox" id="checkbox_2">
    <label for="checkbox_2">Checkbox Label</label>
</div>

### Code

```html
<div class="checkbox checkbox--hover">
  <input type="checkbox" id="checkbox_2" />
  <label for="checkbox_2">Checkbox Label</label>
</div>
```

## Checked

<div class="checkbox">
  <input type="checkbox" id="checkbox_3" checked>
  <label for="checkbox_3"> Checkbox Label</label>
</div>

### Code

```html
<div class="checkbox">
  <input type="checkbox" id="checkbox_3" checked />
  <label for="checkbox_3"> Checkbox Label</label>
</div>
```

## Disabled

<div class="checkbox">
    <input type="checkbox" id="checkbox_4" disabled >
    <label for="checkbox_4">Checkbox Label</label>
</div>

### Code

```html
<div class="checkbox">
  <input type="checkbox" id="checkbox_4" disabled />
  <label for="checkbox_4">Checkbox Label</label>
</div>
```

## Focus

<div class="checkbox checkbox--focus">
    <input type="checkbox" id="checkbox_5">
    <label for="checkbox_5">Checkbox Label</label>
</div>

### Code

```html
<div class="checkbox checkbox--focus">
  <input type="checkbox" id="checkbox_5" />
  <label for="checkbox_5">Checkbox Label</label>
</div>
```

## Form group

<form>
<div class="checkbox mb-4">
  <input type="checkbox" id="checkbox_6">
  <label for="checkbox_6">Checkbox Label</label>
</div>
<div class="checkbox mb-4">
  <input type="checkbox" id="checkbox_7">
  <label for="checkbox_7">Checkbox Label</label>
</div>
<div class="checkbox mb-4">
  <input type="checkbox" id="checkbox_8">
  <label for="checkbox_8">Checkbox Label</label>
</div>
<div class="checkbox mb-4">
  <input type="checkbox" id="checkbox_9">
  <label for="checkbox_9">Checkbox Label</label>
</div>
</form>
