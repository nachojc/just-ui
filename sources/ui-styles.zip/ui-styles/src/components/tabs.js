module.exports = ({addComponents}) => {
  addComponents({
    ".tabs-container": {
      "@apply overflow-x-auto": "",
      "scrollbar-width": "none",
      "&::-webkit-scrollbar": {
        "display": "none",
        "-ms-overflow-style": "none",
      },
      "& .tab": {
        "@apply px-2": "",
      },
      "&.shadowed": {
        "clip-path": "inset(-8px -8px 0px -8px)",
        "@apply shadow-md-active": "",
        "& .active": {
          "@apply shadow-md-active": "",
        },
        "& .tab": {
          "@apply p-4": "",
        },
        "& .tab:not(:first-child, .active)": {
            "box-shadow": `inset 4px 0 4px 0px rgba(55,52,51,0.20)`
          }
      },
      "&.highlighted": {
        // space for shadow to be visible and not overflowed by container
        "@apply px-2 pt-2": "",
        "@apply -mx-2 -mt-2": "",
      },
      "&.overflow-shift": {
        "@apply mr-2": "",
      },
      "&.overflow-shift-left": {
        "@apply pl-8 ml-2":"",
      },
      "& .tab-underlined": {
        "&.active": {
          "@apply border-coral border-b-4": "",
          "& > *": {
            "@apply -mb-1": "",
          },
        },
      },
      "& .tab-rounded": {
        "@apply rounded-t": "",
      },
      "& .tab-highlighted": {
        "@apply shadow-md-active": "",
        "@apply p-4": "",
      },

    },
    ".tab-nav-btn": {
      "height": "120%",
      "top": "-10%",
      "@apply z-10 absolute w-8": "",
    }
  });
};
