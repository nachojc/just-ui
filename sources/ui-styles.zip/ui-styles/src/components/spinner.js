module.exports = ({ addComponents }) => {
  addComponents({
    ".spinner": {
      animation: "spin 3s linear infinite",
      "&--inner": {
        "stroke-dashoffset": 0,
        "stroke-dasharray": 300,
        "stroke-width": 7,
        "stroke-miterlimit": 10,
        "stroke-linecap": "round",
        animation: "spinner 2s linear infinite",
        stroke: "#2fcfa0",
        fill: "transparent"
      }
    },
    "@keyframes spinner": {
      "0%": { "stroke-dashoffset": 0 },
      "100%": { "stroke-dashoffset": -600 }
    },
    "@keyframes spin": {
      from: { transform: "rotate(0deg)" },
      to: { transform: "rotate(360deg)" }
    }
  });
}
