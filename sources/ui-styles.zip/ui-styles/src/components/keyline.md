---
title: "Keyline"
---

## Default

<hr class="keyline">

### Code

```html
<hr class="keyline" />
```
