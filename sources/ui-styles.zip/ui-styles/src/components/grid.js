module.exports = ({ addComponents }) => {
  addComponents({
    ".container": {
      "@apply mx-auto max-w-grid": ""
    },
    ".columns": {
      "@apply flex mx-4": "",
      "@screen md": {
        "&": {
          "@apply mx-12": ""
        }
      },
      "@screen lg": {
        "&": {
          "@apply mx-14": ""
        }
      },
      "@screen xl": {
        "&": {
          "@apply mx-16": ""
        }
      }
    },
    ".column": {
      "@apply px-1": "",
      "@screen md": {
        "&": {
          "@apply px-grid": ""
        }
      }
    }
  });
};
