---
title: "Date"
---

## Default

<div>
    <div class="flex">
      <label for="day-1" class="label">Day</label>
      <label for="month-1" class="label">Month</label>
      <label for="year-1" class="label">Year</label>
    </div>
  <div class="flex">
    <input id="day-1"class="input mr-2" type="text" placeholder="DD" maxlength="2">
    <input id="month-1" class="input mr-2" type="text" placeholder="MM" maxlength="2">
    <input id="year-1" class="input mr-2" type="text" placeholder="YYYY" maxlength="4">
  </div>
</div>

### Code

```html
<div>
  <div class="flex">
    <label for="day-1" class="label">Day</label>
    <label for="month-1" class="label">Month</label>
    <label for="year-1" class="label">Year</label>
  </div>
  <div class="flex">
    <input
      id="day-1"
      class="input mr-2"
      type="text"
      placeholder="DD"
      maxlength="2"
    />
    <input
      id="month-1"
      class="input mr-2"
      type="text"
      placeholder="MM"
      maxlength="2"
    />
    <input
      id="year-1"
      class="input mr-2"
      type="text"
      placeholder="YYYY"
      maxlength="4"
    />
  </div>
</div>
```

## Active

<div>
    <div class="flex">
      <label for="day-2" class="label">Day</label>
      <label for="month-2" class="label">Month</label>
      <label for="year-2" class="label">Year</label>
    </div>
   <div class="flex">
    <input id="day-2" class="input input--active mr-2" type="text" placeholder="DD" maxlength="2">
    <input id="month-2" class="input input--active mr-2" type="text" placeholder="MM" maxlength="2">
    <input id="year-2" class="input input--active mr-2" type="text" placeholder="YYYY" maxlength="4">
  </div>
</div>

### Code

```html
<div>
  <div class="flex">
    <label for="day-2" class="label">Day</label>
    <label for="month-2" class="label">Month</label>
    <label for="year-2" class="label">Year</label>
  </div>
  <div class="flex">
    <input
      id="day-2"
      class="input input--active mr-2"
      type="text"
      placeholder="DD"
      maxlength="2"
    />
    <input
      id="month-2"
      class="input input--active mr-2"
      type="text"
      placeholder="MM"
      maxlength="2"
    />
    <input
      id="year-2"
      class="input input--active mr-2"
      type="text"
      placeholder="YYYY"
      maxlength="4"
    />
  </div>
</div>
```

## Hover

<div>
     <div class="flex">
      <label for="day-3" class="label">Day</label>
      <label for="month-3" class="label">Month</label>
      <label for="year-3" class="label">Year</label>
    </div>
    <div class= "flex">
    <input id="day-3" class="input input--hover mr-2" type="text" placeholder="DD" maxlength="2">
    <input id="month-3" class="input input--hover mr-2" type="text" placeholder="MM" maxlength="2">
    <input id="year-3"class="input input--hover mr-2" type="text" placeholder="YYYY" maxlength="4">
  </div>
</div>

### Code

```html
<div>
  <div class="flex">
    <label for="day-3" class="label">Day</label>
    <label for="month-3" class="label">Month</label>
    <label for="year-3" class="label">Year</label>
  </div>
  <div class="flex">
    <input
      id="day-3"
      class="input input--hover mr-2"
      type="text"
      placeholder="DD"
      maxlength="2"
    />
    <input
      id="month-3"
      class="input input--hover mr-2"
      type="text"
      placeholder="MM"
      maxlength="2"
    />
    <input
      id="year-3"
      class="input input--hover mr-2"
      type="text"
      placeholder="YYYY"
      maxlength="4"
    />
  </div>
</div>
```

## Error

<div>
    <div class="flex">
      <label for="day-4" class="label">Day</label>
      <label for="month-4" class="label">Month</label>
      <label for="year-4" class="label">Year</label>
    </div>
    <div class="flex">
    <input id="day-4" class="input input--error mr-2" type="text" placeholder="DD" maxlength="2">
    <input id="month-4" class="input input--error mr-2" type="text" placeholder="MM" maxlength="2">
    <input id="year-4" class="input input--error mr-2" type="text" placeholder="YYYY" maxlength="4">
  </div>
    <span class="input-message input-message--error">Inline error message<span>
</div>

### Code

```html
<div>
    <div class="flex">
      <label for="day-4" class="label">Day</label>
      <label for="month-4" class="label">Month</label>
      <label for="year-4" class="label">Year</label>
    </div>
    <div class="flex">
    <input id="day-4" class="input input--error mr-2" type="text" placeholder="DD" maxlength="2">
    <input id="month-4" class="input input--error mr-2" type="text" placeholder="MM" maxlength="2">
    <input id="year-4" class="input input--error mr-2" type="text" placeholder="YYYY" maxlength="4">
  </div>
    <span class="input-message input-message--error">Inline error message<span>
</div>
```

## Disabled

<div>
    <div class="flex">
      <label for="day-5" class="label">Day</label>
      <label for="month-5" class="label">Month</label>
      <label for="year-5" class="label">Year</label>
    </div>
   <div class="flex">
    <input id="day-5" class="input mr-2" disabled type="text" placeholder="DD" maxlength="2">
    <input id="month-5" class="input mr-2" disabled type="text" placeholder="MM" maxlength="2">
    <input id="year-5" class="input mr-2" disabled type="text" placeholder="YYYY" maxlength="4">
  </div>
</div>

### Code

```html
<div>
  <div class="flex">
    <label for="day-5" class="label">Day</label>
    <label for="month-5" class="label">Month</label>
    <label for="year-5" class="label">Year</label>
  </div>
  <div class="flex">
    <input
      id="day-5"
      class="input mr-2"
      disabled
      type="text"
      placeholder="DD"
      maxlength="2"
    />
    <input
      id="month-5"
      class="input mr-2"
      disabled
      type="text"
      placeholder="MM"
      maxlength="2"
    />
    <input
      id="year-5"
      class="input mr-2"
      disabled
      type="text"
      placeholder="YYYY"
      maxlength="4"
    />
  </div>
</div>
```
