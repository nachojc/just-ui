module.exports = ({ addComponents }) => {
  addComponents({
    ".support-section": {
      "@apply w-full": "",
      "@screen md": {
        "&": {
          "max-width": "22.5rem"
        }
      }
    }
  });
};
