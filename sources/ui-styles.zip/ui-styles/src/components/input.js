module.exports = ({ addComponents }) => {
  addComponents({
    ".input": {
      "@apply bg-white text-just-black border border-just-black-20 rounded outline-none py-3 px-4 leading-normal w-full appearance-none":
        "",

      "&::placeholder": {
        "@apply opacity-100 text-just-black-32": ""
      },

      "&:hover, &&--hover": {
        "@apply border-just-black-64": ""
      },

      "&:disabled, &&--disabled": {
        "@apply opacity-32 pointer-events-none": ""
      },

      "&&--readonly": {
        "@apply opacity-64 pointer-events-none": ""
      },

      "&:active,&&--active,&:focus,&&--focus": {
        "@apply border-skyan": ""
      },
      "&&--error": {
        "@apply border-tangerine": ""
      }
    },

    ".input-message": {
      "@apply block text-sm pt-1 leading-tight": "",
      "&--error": {
        "@apply text-tangerine": ""
      }
    },

    ".label": {
      "@apply block mb-2 text-sm w-full leading-tight": ""
    },

    ".currency": {
      "border-right": "1px solid rgba(55, 52, 51, 0.2)",
      padding: "12px 16px"
    }
  });
};
