module.exports = ({ addComponents }) => {
  addComponents({
    ".link": {
      "@apply underline text-coral-dark": "",
      "&--no-underline": {
        "@apply no-underline": ""
      },
      "&:active, &--active": {
        "@apply text-just-black": ""
      }
    }
  });
};
