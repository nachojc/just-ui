module.exports = ({ addComponents }) => {
  addComponents({
    ".radio": {
      "@apply relative": "",

      input: {
        "@apply h-5 w-5 opacity-0 absolute": "",
        top: "2px",
        left: "2px"
      },

      label: {
        "@apply inline-block leading-loose text-sm": "",
        "padding-left": "30px"
      },

      "label::before, label::after": {
        "@apply h-5 w-5 absolute": "",
        top: "2px",
        left: "2px",
        content: '""'
      },

      "label::before": {
        "@apply h-5 w-5 absolute border border-just-black-20 rounded-full bg-white":
          "",
        content: "",
        top: "2px",
        left: "2px"
      },

      "label::after": {
        content: "none"
      },

      "input:checked + label::after": {
        "@apply w-2 h-2 bg-just-black absolute border border-just-black rounded-full":
          "",
        content: '""',
        top: "8px",
        left: "8px"
      },

      "input:hover + label::before, &&--hover input > label::before": {
        "@apply border-just-black-64": ""
      },

      "input:checked + label::before": {
        "@apply border-seafoam": ""
      },

      "input:focus + label::before &&--focus input + label::before": {
        "@apply border-skyan": ""
      },

      "&&--error input + label::before": {
        "@apply border-tangerine": ""
      },

      "input:disabled + label::before": {
        "@apply border-just-black-32": ""
      },
      "&--disabled": { "@apply opacity-32 pointer-events-none": "" },
      "&--readonly": { "@apply opacity-64 pointer-events-none": "" }
    }
  });
};
