module.exports = ({ addComponents }) => {
  addComponents({
    ".checkbox": {
      "@apply relative": "",

      input: {
        "@apply h-6 w-6 opacity-0 absolute top-0 left-0": ""
      },

      label: {
        "@apply inline-block pl-8 leading-loose text-sm": ""
      },

      "label::before, label::after": {
        "@apply h-6 w-6 absolute top-0 left-0": "",
        content: '""'
      },

      "label::before": {
        "@apply border border-just-black-32 rounded-sm bg-white": ""
      },

      "label::after": {
        content: "none"
      },

      "input:checked + label::after": {
        content: '""',
        "@apply bg-center bg-no-repeat": "",
        "background-image": `url("data:image/svg+xml;base64,77u/PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij4NCiAgICA8ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPg0KICAgICAgICA8cGF0aCBkPSJNMCAwaDI0djI0SDB6Ii8+DQogICAgICAgIDxwYXRoIGZpbGw9IiMzNzM0MzMiIGQ9Ik05IDE2LjE3TDQuODMgMTJsLTEuNDIgMS40MUw5IDE5IDIxIDdsLTEuNDEtMS40MXoiLz4NCiAgICA8L2c+DQo8L3N2Zz4NCg==")`,
        "background-position": "center",
        "background-repeat": "no-repeat",
        "background-size": "1.25rem 1.25rem"
      },

      "input:hover + label::before, &&--hover input + label::before": {
        "@apply border-just-black-64": ""
      },

      "input:checked + label::before": {
        "@apply border-seafoam": ""
      },

      "input:focus + label::before, &&--focus input + label::before": {
        "@apply border-skyan": ""
      },

      "&__label--disabled": {
        "@apply opacity-32 pointer-events-none": "",
      },
      "input:disabled + label::after": {
        "@apply opacity-32 pointer-events-none": ""
      },
      "input:disabled + label::before": {
        "@apply border-just-black-32": ""
      },
    }
  });
};
