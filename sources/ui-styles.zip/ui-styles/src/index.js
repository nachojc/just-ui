const plugin = require("tailwindcss/plugin");
const reset = require("./base/reset");
const fonts = require("./base/fonts");
const typography = require("./base/typography");
const buttons = require("./components/button");
const fileIcon = require("./components/file-icon");
const popover = require("./components/popover");
const table = require("./components/table");
const dropdown = require("./components/dropdown");
const grid = require("./components/grid");
const checkbox = require("./components/checkbox");
const utilities = require("./utilities/utilities");
const input = require("./components/input");
const keyline = require("./components/keyline");
const link = require("./components/link");
const radio = require("./components/radio");
const spinner = require("./components/spinner");
const footer = require("./components/footer");
const tabs = require("./components/tabs");

module.exports = () =>
  plugin(function(...args) {
    // base
    reset(...args);
    fonts(...args);
    typography(...args);
    grid(...args);

    // components
    buttons(...args);
    fileIcon(...args);
    popover(...args);
    table(...args);
    checkbox(...args);
    dropdown(...args);
    grid(...args);
    input(...args);
    keyline(...args);
    link(...args);
    radio(...args);
    spinner(...args);
    footer(...args);
    tabs(...args);

    // utilities
    utilities(...args);
  });
