---
title: Colour Usage - Coral
---

##### Coral - old

<div class="swatch-usage-coral swatch-usage-coral--coral-old"></div>

##### Usage

<div class="usage-list">
    <div class="usage-list-blocks">
        Usage
    </div>
    <div class="usage-list-compliant">
        AA Compliant
    </div>
</div>

<div class="swatch-usage-coral-container">
    <div class="swatch-usage-coral-text-container">
        <span class="usageLargeText">Regular text 20pt +</span>
        <span class="usageSmallText">Bold text 14pt +</span>
    </div>
    <span class="x-usage-coral">&#x2715</span>
</div>

<div class="swatch-usage-coral-container swatch-usage-coral-container--grey">
    <div class="swatch-usage-coral-text-container">
        <span class="usageLargeText">Regular text 20pt +</span>
        <span class="usageSmallText">Bold text 14pt +</span>
    </div>
    <span class="x-usage-coral">&#x2715</span>
</div>

<div class="swatch-usage-coral-container swatch-usage-coral-container--black">
    <div class="swatch-usage-coral-text-container">
        <span class="usageLargeText">Regular text 20pt +</span>
        <span class="usageSmallText">Bold text 14pt +</span>
    </div>
    <span class="tick-usage-coral">&#x2713</span>
</div>

<div class="swatch-usage-coral-container swatch-usage-coral-container--coral-old">
    <div class="swatch-usage-coral-text-container">
        <span class="usageWhiteLargeText">Regular text 20pt +</span>
        <span class="usageWhiteSmallText">Bold text 14pt +</span>
    </div>
    <span class="x-usage-coral">&#x2715</span>
</div>

##### Coral

<div class="swatch-usage-coral swatch-usage-coral--coral"></div>

##### Usage

<div class="swatch-usage-coral-container">
    <div class="swatch-usage-coral-text-container">
        <span class="usageLargeText">Regular text 20pt +</span>
        <span class="usageSmallText">Bold text 14pt +</span>
    </div>
    <span class="tick-usage-coral">&#x2713</span>
</div>

<div class="swatch-usage-coral-container swatch-usage-coral-container--grey">
    <div class="swatch-usage-coral-text-container">
        <span class="usageLargeText">Regular text 20pt +</span>
        <span class="usageSmallText">Bold text 14pt +</span>
    </div>
    <span class="x-usage-coral">&#x2715</span>
</div>

<div class="swatch-usage-coral-container swatch-usage-coral-container--black">
    <div class="swatch-usage-coral-text-container">
        <span class="usageLargeText">Regular text 20pt +</span>
        <span class="usageSmallText">Bold text 14pt +</span>
    </div>
    <span class="tick-usage-coral">&#x2713</span>
</div>

<div class="swatch-usage-coral-container swatch-usage-coral-container--coral">
    <div class="swatch-usage-coral-text-container">
    <span class="usageWhiteLargeText">Regular text 20pt +</span>
    <span class="usageWhiteSmallText">Bold text 14pt +</span>
    </div>
    <span class="tick-usage-coral">&#x2713</span>
</div>

##### Coral - dark

<div class="swatch-usage-coral swatch-usage-coral--coral-dark"></div>

##### Usage

<div class="swatch-usage-coral-container ">
    <div class="swatch-usage-coral-text-container">
    <span class="usageLargeText">Regular text 20pt +</span>
    <span class="usageSmallText">Bold text 14pt +</span>
    </div>
    <span class="tick-usage-coral">&#x2713</span>
</div>

<div class="swatch-usage-coral-container swatch-usage-coral-container--grey ">
    <div class="swatch-usage-coral-text-container">
    <span class="usageLargeText">Regular text 20pt +</span>
    <span class="usageSmallText">Bold text 14pt +</span>
    </div>
    <span class="tick-usage-coral">&#x2713</span>
</div>

<div class="swatch-usage-coral-container swatch-usage-coral-container--black">
    <div class="swatch-usage-coral-text-container">
    <span class="usageLargeText">Regular text 20pt +</span> 
    <span class="usageSmallText">Bold text 14pt +</span>
    </div>
    <span class="x-usage-coral">&#x2715</span>
</div>

<div class="swatch-usage-coral-container swatch-usage-coral-container--coral-dark ">
    <div class="swatch-usage-coral-text-container">
    <span class="usageWhiteSmallText">Regular text 14pt +</span>
    </div>
    <span class="tick-usage-coral">&#x2713</span>
</div>
