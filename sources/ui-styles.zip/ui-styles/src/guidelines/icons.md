---
title: Icons
---

###Inactive

<div class="mb-4">
    <i class="w-12 h-12 icn icn-account-inactive"></i>
    <i class="w-12 h-12 icn icn-archive-inactive"></i>
    <i class="w-12 h-12 icn icn-chevron-down-inactive"></i>
    <i class="w-12 h-12 icn icn-close-inactive"></i>
    <i class="w-12 h-12 icn icn-copy-inactive"></i>
    <i class="w-12 h-12 icn icn-edit-inactive"></i>
    <i class="w-12 h-12 icn icn-delete-inactive"></i>
    <i class="w-12 h-12 icn icn-ellipsis-vertical-inactive"></i>
    <i class="w-12 h-12 icn icn-help-inactive"></i>
    <i class="w-12 h-12 icn icn-home-inactive"></i>
    <i class="w-12 h-12 icn icn-pdf-inactive"></i>
    <i class="w-12 h-12 icn icn-plus-inactive"></i>
    <i class="w-12 h-12 icn icn-power-settings-inactive"></i>
    <i class="w-12 h-12 icn icn-search-inactive"></i>
    <i class="w-12 h-12 icn icn-unarchive-inactive"></i>
</div>

###Active

<div class="mb-4">
    <i class="w-12 h-12 icn icn-account"></i>
    <i class="w-12 h-12 icn icn-archive"></i>
    <i class="w-12 h-12 icn icn-chevron-down"></i>
    <i class="w-12 h-12 icn icn-close"></i>
    <i class="w-12 h-12 icn icn-copy"></i>
    <i class="w-12 h-12 icn icn-edit"></i>
    <i class="w-12 h-12 icn icn-delete"></i>
    <i class="w-12 h-12 icn icn-ellipsis-vertical"></i>
    <i class="w-12 h-12 icn icn-help"></i>
    <i class="w-12 h-12 icn icn-home"></i>
    <i class="w-12 h-12 icn icn-pdf"></i>
    <i class="w-12 h-12 icn icn-plus"></i>
    <i class="w-12 h-12 icn icn-power-settings"></i>
    <i class="w-12 h-12 icn icn-search"></i>
    <i class="w-12 h-12 icn icn-unarchive"></i>
</div>

###Hoverable

<div class="mb-4">
    <i class="w-12 h-12 cursor-pointer icn icn-account-inactive hover:icn-account"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-archive-inactive hover:icn-archive"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-chevron-down-inactive hover:icn-chevron-down"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-close-inactive hover:icn-close"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-copy-inactive hover:icn-copy"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-edit-inactive hover:icn-edit"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-delete-inactive hover:icn-delete"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-ellipsis-vertical-inactive hover:icn-ellipsis-vertical"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-help-inactive hover:icn-help"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-home-inactive hover:icn-home"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-pdf-inactive hover:icn-pdf"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-plus-inactive hover:icn-plus"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-power-settings-inactive hover:icn-power-settings"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-search-inactive hover:icn-search"></i>
    <i class="w-12 h-12 cursor-pointer icn icn-unarchive-inactive hover:icn-unarchive"></i>
</div>

###Others
####Small

<div class="mb-4">
    <i class="w-12 h-12 icn icn-arrow-dropdown"></i>
    <i class="w-12 h-12 icn icn-attention"></i>
    <i class="w-12 h-12 icn icn-burger-menu"></i>
    <i class="w-12 h-12 icn icn-check"></i>
    <i class="w-12 h-12 icn icn-circle-grey"></i>
    <i class="w-12 h-12 icn icn-circle-green"></i>
    <i class="w-12 h-12 icn icn-circle-tick-green"></i>
    <i class="w-12 h-12 icn icn-notifications-inactive"></i>
    <i class="w-12 h-12 icn icn-notifications-active"></i>
    <i class="w-12 h-12 icn icn-visibility"></i>
    <i class="w-12 h-12 icn icn-visibility-off"></i>
    <i class="w-12 h-12 icn icn-info"></i>
</div>

####Large

<div>
    <i class="w-24 h-24 icn icn-success"></i>
    <i class="w-24 h-24 icn icn-warning"></i>
    <i class="w-24 h-24 icn icn-locked"></i>
    <i class="w-24 h-24 icn icn-search-notfound"></i>
</div>
