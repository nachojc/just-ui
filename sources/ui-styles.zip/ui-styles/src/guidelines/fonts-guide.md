---
title: Fonts
---

### To be used with all Just digital design

<p class="font-just-script">Aa Zz 123<p> 
<p class="font-just-script"> Just Script<p>

<p>Aa Zz 123<p> 
<p> Just Sans<p>
