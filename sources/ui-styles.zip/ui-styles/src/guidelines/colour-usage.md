---
title: Colour Usage
---

<div class="swatch swatch--small inlineBlock bg-coral">
        <div class="swatch__colour"></div>
    <div class="swatch__content">
        <span class="swatch__heading">CORAL</span>
    </div>
</div>
<p class="inlineBlock">Display background / Primary button background</p>
<br>
<br>
<div class="swatch swatch--small inlineBlock bg-coral-dark">
        <div class="swatch__colour"></div>
    <div class="swatch__content">
        <span class="swatch__heading">CORAL DARK</span>
    </div>
</div>
<p class="inlineBlock">Small coral text / Links / Secondary button text</p>
<br>
<br>
<div class="swatch swatch--small inlineBlock bg-just-black">
        <div class="swatch__colour"></div>
    <div class="swatch__content">
        <span class="swatch__heading">JUST BLACK</span>
    </div>
</div>
<p class="inlineBlock">Primary text</p>
<br>
<br>
<div class="swatch swatch--small inlineBlock bg-just-black-64">
        <div class="swatch__colour"></div>
    <div class="swatch__content">
        <span class="swatch__heading">JUST BLACK 64%</span>
    </div>
</div>
<p class="inlineBlock">Secondary text</p>
<br>
<br>
<div class="swatch swatch--small inlineBlock bg-just-black-32">
        <div class="swatch__colour"></div>
    <div class="swatch__content">
        <span class="swatch__heading">JUST BLACK 32%</span>
    </div>
</div>
<p class="inlineBlock">Disabled text / Placeholder text</p>
<br>
<br>
<div class="swatch swatch--small inlineBlock bg-just-black-20">
        <div class="swatch__colour"></div>
    <div class="swatch__content">
        <span class="swatch__heading">JUST BLACK 20%</span>
    </div>
</div>
<p class="inlineBlock">Borders</p>
<br>
<br>
<div class="swatch swatch--small inlineBlock bg-just-black-12">
        <div class="swatch__colour"></div>
    <div class="swatch__content">
        <span class="swatch__heading">JUST BLACK 12%</span>
    </div>
</div>
<p class="inlineBlock">Keylines / Shadows / Tonal overlay</p>
<br>
<br>
<div class="swatch swatch--small inlineBlock bg-tangerine">
        <div class="swatch__colour"></div>
    <div class="swatch__content">
        <span class="swatch__heading">TANGERINE</span>
    </div>
</div>
<p class="inlineBlock">Invalid / Warning</p>
<br>
<br>
<div class="swatch swatch--small inlineBlock bg-seafoam">
        <div class="swatch__colour"></div>
    <div class="swatch__content">
        <span class="swatch__heading">SEAFOAM</span>
    </div>
</div>
<p class="inlineBlock">Valid / Success</p>
<br>
<br>
<div class="swatch swatch--small inlineBlock bg-skyan">
        <div class="swatch__colour"></div>
    <div class="swatch__content">
        <span class="swatch__heading">SKYAN</span>
    </div>
</div>
<p class="inlineBlock">Focus / Active</p>
<br>
<br>
<div class="swatch swatch--small inlineBlock bg-white">
        <div class="swatch__colour"></div>
    <div class="swatch__content">
        <span class="swatch__heading">WHITE</span>
    </div>
</div>
<p class="inlineBlock">Surface</p>
<br>
<br>
