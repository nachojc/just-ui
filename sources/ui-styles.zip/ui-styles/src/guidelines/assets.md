---
title: Assets
---

<p>Assets here are by default the smallest instance used size. Refer to screen designs to see how they need to scale (e.g. for M, L or XL breakpoints)<p>

##### Interstitial assets

<span class="lockedImg"></span>
<span class="successImg"></span>
<span class="warningImg"></span>
