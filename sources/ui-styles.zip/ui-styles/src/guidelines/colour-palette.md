---
title: "Colour Palette"
---

<div class="swatch-container">
  <div class="swatch bg-coral">
    <div class="swatch__colour"></div>
    <div class="swatch__content">
      <span class="swatch__heading">coral</span>
      <span class="swatch__text">#f36768</span>
      <span class="swatch__text">rgba(243, 103, 104, 1)</span>
    </div>
  </div>
  <div class="swatch bg-coral-dark">
    <div class="swatch__colour"></div>
    <div class="swatch__content">
      <span class="swatch__heading">coral dark</span>
      <span class="swatch__text">#d73c3c</span>
      <span class="swatch__text">rgba(215, 60, 60, 1)</span>
    </div>
  </div>
</div>
<div class="swatch-container">
  <div class="swatch bg-tangerine">
    <div class="swatch__colour">
    </div>
    <div class="swatch__content">
      <span class="swatch__heading">tangerine</span>
      <span class="swatch__text">#ff9c54</span>
      <span class="swatch__text">rgba(255, 156, 84, 1)</span>
    </div>
  </div>
  <div class="swatch bg-lemon">
    <div class="swatch__colour">
    </div>
    <div class="swatch__content">
      <span class="swatch__heading">lemon</span>
      <span class="swatch__text">#ffe063</span>
      <span class="swatch__text">rgba(255, 224, 99, 1)</span>
    </div>
  </div>
  <div class="swatch bg-seafoam">
    <div class="swatch__colour">
    </div>
    <div class="swatch__content">
      <span class="swatch__heading">seafoam</span>
      <span class="swatch__text">#2fcfa0</span>
      <span class="swatch__text">rgba(47, 207, 160, 1)</span>
    </div>
  </div>
  <div class="swatch bg-skyan">
    <div class="swatch__colour">
    </div>
    <div class="swatch__content" >
      <span class="swatch__heading">skyan</span>
      <span class="swatch__text">#21c7eb</span>
      <span class="swatch__text">rgba(33, 199, 235, 1)</span>
    </div>
  </div>
  <div class="swatch bg-lavendar">
    <div class="swatch__colour">
    </div>
    <div class="swatch__content">
      <span class="swatch__heading">lavendar</span>
      <span class="swatch__text">#c489dc</span>
      <span class="swatch__text">rgba(196, 137, 220, 1)</span>
    </div>
  </div>
</div>
<div class="swatch-container">
  <div class="swatch bg-black-light">
    <div class="swatch__colour">
    </div>
    <div class="swatch__content">
      <span class="swatch__heading">black light</span>
      <span class="swatch__text">#f2f2f2</span>
      <span class="swatch__text">rgba(242, 242, 242, 1)</span>
    </div>
  </div>
  <div class="swatch bg-black-mid">
    <div class="swatch__colour">
    </div>
    <div class="swatch__content">
      <span class="swatch__heading">black mid</span>
      <span class="swatch__text">#b5b8ba</span>
      <span class="swatch__text">rgba(181, 184, 186, 1)</span>
    </div>
  </div>
  <div class="swatch bg-just-black">
    <div class="swatch__colour">
    </div>
    <div class="swatch__content">
      <span class="swatch__heading">just black</span>
      <span class="swatch__text">#373433</span>
      <span class="swatch__text">rgba(55, 52, 51, 1)</span>
    </div>
  </div>
</div>
<div class="swatch-container">
  <div class="swatch bg-white">
    <div class="swatch__colour"></div>
    <div class="swatch__content">
      <span class="swatch__heading">white</span>
      <span class="swatch__text">#ffffff</span>
      <span class="swatch__text">rgba(255, 255, 255, 1)</span>
    </div>
  </div>
  <div class="swatch bg-just-black-64">
    <div class="swatch__colour">
    </div>
    <div class="swatch__content">
      <span class="swatch__heading">black 64</span>
      <span class="swatch__text">#373433</span>
      <span class="swatch__text">rgba(55, 52, 51, 0.64)</span>
    </div>
  </div>
  <div class="swatch bg-just-black-32">
    <div class="swatch__colour">
    </div>
    <div class="swatch__content">
      <span class="swatch__heading">black 32</span>
      <span class="swatch__text">#373433</span>
      <span class="swatch__text">rgba(55, 52, 51, 0.32)</span>
    </div>
  </div>
  <div class="swatch bg-just-black-20">
    <div class="swatch__colour">
    </div>
    <div class="swatch__content">
      <span class="swatch__heading">black 20</span> 
      <span class="swatch__text">#373433</span>  
      <span class="swatch__text">rgba(55, 52, 51, 0.20)</span>
    </div>
  </div>
  <div class="swatch bg-just-black-12">
    <div class="swatch__colour">
    </div>
    <div class="swatch__content">
      <span class="swatch__heading">black 12</span> 
      <span class="swatch__text">#373433</span> 
      <span class="swatch__text">rgba(55, 52, 51, 0.12)</span>
    </div>
  </div>
</div>
