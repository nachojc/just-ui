---
title: Typography
---

### Example

<p class="title-1">
  Title 1   
  &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Title 1 - bold
  </span>
</p>

<p class="title-2">
  Title 2
  &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Title 2 - bold
  </span>
</p>

<p class="subtitle-1">
  Subtitle 1
  &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Subtitle 1 - bold
  </span>
</p>

<p class="subtitle-2">
  Subtitle 2
  &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Subtitle 2 - bold
  </span>
    &nbsp;&#47;&nbsp;
  <span class="secondary">
    Subtitle 2 - secondary
  </span>
</p>

<p>
  Body 1
  &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Body 1 - bold
  </span>
    &nbsp;&#47;&nbsp;
  <span class="secondary">
    Body 1 - secondary
  </span>
</p>

<p class="body-2">
  Body 2
  &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Body 2 - bold
  </span>
    &nbsp;&#47;&nbsp;
  <span class="secondary">
    Body 2 - secondary
  </span>
</p>

<p class="note">
  Note
  &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Note - bold
  </span>
    &nbsp;&#47;&nbsp;
  <span class="secondary">
    Note - secondary
  </span>
</p>

### Code

```html
<p class="title-1">
  Title 1 &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Title 1 - bold
  </span>
</p>

<p class="title-2">
  Title 2 &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Title 2 - bold
  </span>
</p>

<p class="subtitle-1">
  Subtitle 1 &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Subtitle 1 - bold
  </span>
</p>

<p class="subtitle-2">
  Subtitle 2 &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Subtitle 2 - bold
  </span>
  &nbsp;&#47;&nbsp;
  <span class="secondary">
    Subtitle 2 - secondary
  </span>
</p>

<p>
  Body 1 &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Body 1 - bold
  </span>
  &nbsp;&#47;&nbsp;
  <span class="secondary">
    Body 1 - secondary
  </span>
</p>

<p class="body-2">
  Body 2 &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Body 2 - bold
  </span>
  &nbsp;&#47;&nbsp;
  <span class="secondary">
    Body 2 - secondary
  </span>
</p>

<p class="note">
  Note &nbsp;&#47;&nbsp;
  <span class="font-bold">
    Note - bold
  </span>
  &nbsp;&#47;&nbsp;
  <span class="secondary">
    Note - secondary
  </span>
</p>
```
