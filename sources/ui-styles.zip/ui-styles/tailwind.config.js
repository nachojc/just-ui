module.exports = {
  presets: [require("./tailwind-preset.js")]
};
