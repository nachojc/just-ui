const pify = require("pify");
const { writeFile } = pify(require("fs"));
const postcss = require("postcss");
const tailwindcss = require("tailwindcss");

const plugins = [
  tailwindcss(),
  require("postcss-url")({
    url: "inline"
  }),
  require("autoprefixer")
]

const minifiedPlugins = [
  ...plugins,
  require("cssnano")({
    preset: "default"
  })
];

const from = "./src/index.css";
const to = "./dist/jui.css";
const toMinified = "./dist/jui.min.css";

async function build() {
  try {
    const postCssResult = await postcss(plugins).process(from, {
      from,
      to
    });
    const minifiedPostCssResult = await postcss(minifiedPlugins).process(from, {
      from,
      to: toMinified
    });
    writeFile(toMinified, minifiedPostCssResult.css);
    writeFile(to, postCssResult.css);
  } catch (e) {
    console.error(e);
  }
}

build();
