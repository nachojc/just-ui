const pify = require("pify");
const { writeFile } = pify(require("fs"));
const sass = require("sass");
const postcss = require("postcss");
const tailwindcss = require("tailwindcss");
const postcssColorMod = require("postcss-color-mod-function")

const plugins = [
  tailwindcss(),
  postcssColorMod(),
  require("postcss-url")({
    url: "inline"
  }),
  require("autoprefixer")
];

const minifiedPlugins = [
  ...plugins,
  require("cssnano")({
    preset: "default"
  })
];

const from = "./src/index.css";
const to = "./dist/jui.css";
const toMinified = "./dist/jui.min.css";

async function build() {
  const sassResult = sass.compile(from);
  try {
    const postCssResult = await postcss(plugins).process(sassResult.css, {
      from,
      to
    });
    const minifiedPostCssResult = await postcss(minifiedPlugins).process(
      sassResult.css,
      {
        from,
        to: toMinified
      }
    );
    writeFile(toMinified, minifiedPostCssResult.css);
    writeFile(to, postCssResult.css);
  } catch (e) {
    console.error(e);
  }
}

build()
