# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.3.9](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.3.8...@just-delivery/ui-styles@0.3.9) (2024-07-04)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.3.8](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.3.7...@just-delivery/ui-styles@0.3.8) (2024-02-28)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.3.7](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.3.6...@just-delivery/ui-styles@0.3.7) (2023-12-21)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.3.6](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.3.5...@just-delivery/ui-styles@0.3.6) (2023-04-23)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.3.5](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.3.4...@just-delivery/ui-styles@0.3.5) (2023-01-27)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.3.4](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.3.3...@just-delivery/ui-styles@0.3.4) (2023-01-27)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.3.3](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.3.2...@just-delivery/ui-styles@0.3.3) (2023-01-27)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.3.2](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.3.1...@just-delivery/ui-styles@0.3.2) (2023-01-27)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.3.1](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.3.0...@just-delivery/ui-styles@0.3.1) (2023-01-27)

**Note:** Version bump only for package @just-delivery/ui-styles

# [0.3.0](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.29...@just-delivery/ui-styles@0.3.0) (2023-01-27)

- BREAKING CHANGE: Tailwind upgrade ([e69d9e9](https://github.com/Just-Delivery/ui-components-web/commit/e69d9e9963a7d88f99aa7e4dde83a1138de7ba59))

### BREAKING CHANGES

- Tailwind upgrade

# [0.3.0](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.29...@just-delivery/ui-styles@0.3.0) (2023-01-27)

- BREAKING CHANGE: Tailwind upgrade ([e69d9e9](https://github.com/Just-Delivery/ui-components-web/commit/e69d9e9963a7d88f99aa7e4dde83a1138de7ba59))

### BREAKING CHANGES

- Tailwind upgrade

## [0.2.29](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.28...@just-delivery/ui-styles@0.2.29) (2022-10-18)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.2.28](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.27...@just-delivery/ui-styles@0.2.28) (2022-10-18)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.2.27](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.26...@just-delivery/ui-styles@0.2.27) (2022-10-18)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.2.26](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.25...@just-delivery/ui-styles@0.2.26) (2022-10-06)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.2.25](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.24...@just-delivery/ui-styles@0.2.25) (2022-10-06)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.2.24](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.23...@just-delivery/ui-styles@0.2.24) (2022-10-06)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.2.23](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.22...@just-delivery/ui-styles@0.2.23) (2022-08-17)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.2.22](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.21...@just-delivery/ui-styles@0.2.22) (2022-07-26)

### Bug Fixes

- Delete csv icon ([95736ab](https://github.com/Just-Delivery/ui-components-web/commit/95736ab))

## [0.2.21](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.20...@just-delivery/ui-styles@0.2.21) (2022-07-26)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.2.20](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.19...@just-delivery/ui-styles@0.2.20) (2022-07-25)

### Bug Fixes

- **#10002:** Add csv icon ([bc13f13](https://github.com/Just-Delivery/ui-components-web/commit/bc13f13)), closes [#10002](https://github.com/Just-Delivery/ui-components-web/issues/10002)

## [0.2.19](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.18...@just-delivery/ui-styles@0.2.19) (2022-07-25)

### Bug Fixes

- **#10001:** delete csv icon ([65f7d0f](https://github.com/Just-Delivery/ui-components-web/commit/65f7d0f)), closes [#10001](https://github.com/Just-Delivery/ui-components-web/issues/10001)

## [0.2.18](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.17...@just-delivery/ui-styles@0.2.18) (2022-07-03)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.2.17](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.16...@just-delivery/ui-styles@0.2.17) (2022-04-22)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.2.16](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.15...@just-delivery/ui-styles@0.2.16) (2022-04-12)

### Bug Fixes

- **#70937:** Edit csv icon ([f9f179f](https://github.com/Just-Delivery/ui-components-web/commit/f9f179f)), closes [#70937](https://github.com/Just-Delivery/ui-components-web/issues/70937)

## [0.2.15](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.14...@just-delivery/ui-styles@0.2.15) (2022-04-12)

### Bug Fixes

- **#70937:** Add csv icon ([afb599c](https://github.com/Just-Delivery/ui-components-web/commit/afb599c)), closes [#70937](https://github.com/Just-Delivery/ui-components-web/issues/70937)

## [0.2.14](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.13...@just-delivery/ui-styles@0.2.14) (2021-12-16)

### Bug Fixes

- Update dependencies ([6186ef6](https://github.com/Just-Delivery/ui-components-web/commit/6186ef6))

## [0.2.13](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.12...@just-delivery/ui-styles@0.2.13) (2021-12-08)

### Bug Fixes

- **#65336:** add 4xl font-size ([8c5f81f](https://github.com/Just-Delivery/ui-components-web/commit/8c5f81f)), closes [#65336](https://github.com/Just-Delivery/ui-components-web/issues/65336)

## [0.2.12](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.11...@just-delivery/ui-styles@0.2.12) (2021-12-07)

### Bug Fixes

- **#65119:** Sliding panel styles fix ([51704eb](https://github.com/Just-Delivery/ui-components-web/commit/51704eb)), closes [#65119](https://github.com/Just-Delivery/ui-components-web/issues/65119) [#65119](https://github.com/Just-Delivery/ui-components-web/issues/65119) [#65119](https://github.com/Just-Delivery/ui-components-web/issues/65119)

## [0.2.11](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.10...@just-delivery/ui-styles@0.2.11) (2021-12-06)

### Bug Fixes

- **#65119:** Add sliding-out-panel component ([214b55e](https://github.com/Just-Delivery/ui-components-web/commit/214b55e)), closes [#65119](https://github.com/Just-Delivery/ui-components-web/issues/65119) [#65119](https://github.com/Just-Delivery/ui-components-web/issues/65119) [#65119](https://github.com/Just-Delivery/ui-components-web/issues/65119)

## [0.2.10](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.9...@just-delivery/ui-styles@0.2.10) (2021-10-28)

### Bug Fixes

- **#57183:** Popover styles fix ([209315b](https://github.com/Just-Delivery/ui-components-web/commit/209315b)), closes [#57183](https://github.com/Just-Delivery/ui-components-web/issues/57183)

## [0.2.9](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.8...@just-delivery/ui-styles@0.2.9) (2021-10-15)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.2.8](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.7...@just-delivery/ui-styles@0.2.8) (2021-08-31)

### Bug Fixes

- rollback changes for trigger version ([f450f0a](https://github.com/Just-Delivery/ui-components-web/commit/f450f0a))

## [0.2.7](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.6...@just-delivery/ui-styles@0.2.7) (2021-08-31)

### Bug Fixes

- trigger to publish ui-styles lib ([145f687](https://github.com/Just-Delivery/ui-components-web/commit/145f687))
- trigger to publish ui-styles lib ([8ae36fa](https://github.com/Just-Delivery/ui-components-web/commit/8ae36fa))
- trigger to publish ui-styles lib ([6eac777](https://github.com/Just-Delivery/ui-components-web/commit/6eac777))

## [0.2.6](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.5...@just-delivery/ui-styles@0.2.6) (2021-08-10)

### Bug Fixes

- **123456:** add new color ([f35b58d](https://github.com/Just-Delivery/ui-components-web/commit/f35b58d))

## [0.2.5](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.4...@just-delivery/ui-styles@0.2.5) (2021-07-28)

### Bug Fixes

- **52011:** Menu refactoring ([#93](https://github.com/Just-Delivery/ui-components-web/issues/93)) ([a5cc66f](https://github.com/Just-Delivery/ui-components-web/commit/a5cc66f))

## [0.2.4](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.3...@just-delivery/ui-styles@0.2.4) (2021-07-21)

### Bug Fixes

- **57971:** Spinner ([#98](https://github.com/Just-Delivery/ui-components-web/issues/98)) ([a0b4955](https://github.com/Just-Delivery/ui-components-web/commit/a0b4955))

## [0.2.3](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.2...@just-delivery/ui-styles@0.2.3) (2021-07-07)

### Bug Fixes

- **56645:** Draft saving ([#97](https://github.com/Just-Delivery/ui-components-web/issues/97)) ([55d6f4b](https://github.com/Just-Delivery/ui-components-web/commit/55d6f4b))

## [0.2.2](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.1...@just-delivery/ui-styles@0.2.2) (2021-06-10)

### Bug Fixes

- **51509:** Rework icons ([#92](https://github.com/Just-Delivery/ui-components-web/issues/92)) ([1fa8353](https://github.com/Just-Delivery/ui-components-web/commit/1fa8353))

## [0.2.1](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.2.0...@just-delivery/ui-styles@0.2.1) (2021-06-08)

### Bug Fixes

- added warning icon ([51c3b6d](https://github.com/Just-Delivery/ui-components-web/commit/51c3b6d))

# [0.2.0](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.23...@just-delivery/ui-styles@0.2.0) (2021-06-08)

### Features

- **52549:** Add missed readonly prop ([#91](https://github.com/Just-Delivery/ui-components-web/issues/91)) ([62687e2](https://github.com/Just-Delivery/ui-components-web/commit/62687e2))

## [0.1.23](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.22...@just-delivery/ui-styles@0.1.23) (2021-06-03)

### Bug Fixes

- added download icon ([33bd721](https://github.com/Just-Delivery/ui-components-web/commit/33bd721))

## [0.1.22](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.21...@just-delivery/ui-styles@0.1.22) (2021-05-26)

### Bug Fixes

- Add cloud-upload-icon.svg ([8843737](https://github.com/Just-Delivery/ui-components-web/commit/8843737))

## [0.1.21](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.20...@just-delivery/ui-styles@0.1.21) (2021-05-19)

### Bug Fixes

- add new icon ([11f31f6](https://github.com/Just-Delivery/ui-components-web/commit/11f31f6))

## [0.1.20](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.19...@just-delivery/ui-styles@0.1.20) (2021-05-14)

### Bug Fixes

- delete direct-debit-icon ([5f1886e](https://github.com/Just-Delivery/ui-components-web/commit/5f1886e))

## [0.1.19](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.18...@just-delivery/ui-styles@0.1.19) (2021-05-14)

### Bug Fixes

- Add new icon ([e7b794f](https://github.com/Just-Delivery/ui-components-web/commit/e7b794f))

## [0.1.18](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.17...@just-delivery/ui-styles@0.1.18) (2021-05-13)

### Bug Fixes

- Refactor menu and progress bar ([#88](https://github.com/Just-Delivery/ui-components-web/issues/88)) ([338f8da](https://github.com/Just-Delivery/ui-components-web/commit/338f8da))

## [0.1.17](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.16...@just-delivery/ui-styles@0.1.17) (2021-05-12)

### Bug Fixes

- Add necessary icon ([c12eed5](https://github.com/Just-Delivery/ui-components-web/commit/c12eed5))

## [0.1.16](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.15...@just-delivery/ui-styles@0.1.16) (2021-05-04)

### Bug Fixes

- change className for readonly input ([#84](https://github.com/Just-Delivery/ui-components-web/issues/84)) ([4e9079c](https://github.com/Just-Delivery/ui-components-web/commit/4e9079c))

## [0.1.15](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.14...@just-delivery/ui-styles@0.1.15) (2021-05-03)

### Bug Fixes

- add new icons ([42db1a4](https://github.com/Just-Delivery/ui-components-web/commit/42db1a4))

## [0.1.14](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.13...@just-delivery/ui-styles@0.1.14) (2021-05-03)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.1.13](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.12...@just-delivery/ui-styles@0.1.13) (2021-04-30)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.1.12](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.11...@just-delivery/ui-styles@0.1.12) (2021-04-25)

### Bug Fixes

- Add search-not-found-icon.svg ([bbeecb6](https://github.com/Just-Delivery/ui-components-web/commit/bbeecb6))

## [0.1.11](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.10...@just-delivery/ui-styles@0.1.11) (2021-04-24)

### Bug Fixes

- Rename icons ([046c267](https://github.com/Just-Delivery/ui-components-web/commit/046c267))

## [0.1.10](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.9...@just-delivery/ui-styles@0.1.10) (2021-04-24)

### Bug Fixes

- Remove dimensions for icons ([c22326e](https://github.com/Just-Delivery/ui-components-web/commit/c22326e))

## [0.1.9](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.8...@just-delivery/ui-styles@0.1.9) (2021-04-23)

### Bug Fixes

- Add icon for testing ([627dbfd](https://github.com/Just-Delivery/ui-components-web/commit/627dbfd))

## [0.1.8](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.7...@just-delivery/ui-styles@0.1.8) (2021-04-23)

### Bug Fixes

- Add icons package ([d303631](https://github.com/Just-Delivery/ui-components-web/commit/d303631))

## [0.1.7](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.6...@just-delivery/ui-styles@0.1.7) (2021-04-22)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.1.6](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.5...@just-delivery/ui-styles@0.1.6) (2021-04-13)

### Bug Fixes

- Rework icons to be generated using variants ([#78](https://github.com/Just-Delivery/ui-components-web/issues/78)) ([7e59ea4](https://github.com/Just-Delivery/ui-components-web/commit/7e59ea4))

## [0.1.5](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.4...@just-delivery/ui-styles@0.1.5) (2021-04-12)

### Bug Fixes

- Add opacity styles for not hovered icons ([0414543](https://github.com/Just-Delivery/ui-components-web/commit/0414543))

## [0.1.4](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.3...@just-delivery/ui-styles@0.1.4) (2021-04-12)

### Bug Fixes

- Rename classes for easier purging ([eb0af1b](https://github.com/Just-Delivery/ui-components-web/commit/eb0af1b))

## [0.1.3](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.2...@just-delivery/ui-styles@0.1.3) (2021-04-12)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.1.2](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-styles@0.1.1...@just-delivery/ui-styles@0.1.2) (2021-04-07)

**Note:** Version bump only for package @just-delivery/ui-styles

## 0.1.1 (2021-04-05)

**Note:** Version bump only for package @just-delivery/ui-styles

## [0.7.4](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.7.3...@just-delivery/ui-components@0.7.4) (2021-04-03)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.7.3](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.7.2...@just-delivery/ui-components@0.7.3) (2021-04-02)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.7.2](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.7.1...@just-delivery/ui-components@0.7.2) (2021-04-02)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.7.1](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.7.0...@just-delivery/ui-components@0.7.1) (2021-04-02)

**Note:** Version bump only for package @just-delivery/ui-components

# [0.7.0](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.21...@just-delivery/ui-components@0.7.0) (2021-04-02)

### Features

- build 0.7.0 version ([eb989c2](https://github.com/Just-Delivery/ui-components-web/commit/eb989c2))

## [0.6.21](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.20...@just-delivery/ui-components@0.6.21) (2021-04-02)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.20](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.19...@just-delivery/ui-components@0.6.20) (2021-04-02)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.20](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.19...@just-delivery/ui-components@0.6.20) (2021-04-02)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.19](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.18...@just-delivery/ui-components@0.6.19) (2021-04-02)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.18](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.17...@just-delivery/ui-components@0.6.18) (2021-04-02)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.17](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.16...@just-delivery/ui-components@0.6.17) (2021-04-02)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.16](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.15...@just-delivery/ui-components@0.6.16) (2021-04-02)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.15](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.14...@just-delivery/ui-components@0.6.15) (2021-04-02)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.14](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.13...@just-delivery/ui-components@0.6.14) (2021-04-02)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.13](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.12...@just-delivery/ui-components@0.6.13) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.12](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.11...@just-delivery/ui-components@0.6.12) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.11](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.10...@just-delivery/ui-components@0.6.11) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.10](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.9...@just-delivery/ui-components@0.6.10) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.9](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.8...@just-delivery/ui-components@0.6.9) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.8](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.7...@just-delivery/ui-components@0.6.8) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.7](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.6...@just-delivery/ui-components@0.6.7) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.6](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.5...@just-delivery/ui-components@0.6.6) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.5](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.4...@just-delivery/ui-components@0.6.5) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.4](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.3...@just-delivery/ui-components@0.6.4) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.3](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.2...@just-delivery/ui-components@0.6.3) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.2](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.1...@just-delivery/ui-components@0.6.2) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

## [0.6.1](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.6.0...@just-delivery/ui-components@0.6.1) (2021-04-01)

**Note:** Version bump only for package @just-delivery/ui-components

# [0.6.0](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.5.0...@just-delivery/ui-components@0.6.0) (2021-04-01)

### Features

- increase version [#3](https://github.com/Just-Delivery/ui-components-web/issues/3) ([679a5fe](https://github.com/Just-Delivery/ui-components-web/commit/679a5fe))

# [0.5.0](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.4.1...@just-delivery/ui-components@0.5.0) (2021-04-01)

### Features

- **47309:** wip migrate tailwind plugin ([c37a648](https://github.com/Just-Delivery/ui-components-web/commit/c37a648))

## [0.4.1](https://github.com/Just-Delivery/ui-components-web/compare/@just-delivery/ui-components@0.4.0...@just-delivery/ui-components@0.4.1) (2019-10-09)

### Bug Fixes

- fixed repository field ([756090a](https://github.com/Just-Delivery/ui-components-web/commit/756090a))

# 0.4.0 (2019-10-09)

### Bug Fixes

- added background colors on components ([#74](https://github.com/Just-Delivery/ui-components-web/issues/74)) ([b25545e](https://github.com/Just-Delivery/ui-components-web/commit/b25545e))
- added fullstop ([cd98903](https://github.com/Just-Delivery/ui-components-web/commit/cd98903))
- added spacing to grid example ([#67](https://github.com/Just-Delivery/ui-components-web/issues/67)) ([644d05f](https://github.com/Just-Delivery/ui-components-web/commit/644d05f))
- changed build dist folder management to rimraf ([48523a0](https://github.com/Just-Delivery/ui-components-web/commit/48523a0))
- changed build dist folder management to rimraf ([994f7a7](https://github.com/Just-Delivery/ui-components-web/commit/994f7a7))
- changed build dist folder management to rimraf ([3f8c38d](https://github.com/Just-Delivery/ui-components-web/commit/3f8c38d))
- fixed invalid grid spacing property ([fbe42b4](https://github.com/Just-Delivery/ui-components-web/commit/fbe42b4))
- removed commented out code ([7c0883d](https://github.com/Just-Delivery/ui-components-web/commit/7c0883d))
- updated date component labels ([#71](https://github.com/Just-Delivery/ui-components-web/issues/71)) ([d0c5968](https://github.com/Just-Delivery/ui-components-web/commit/d0c5968))

### Features

- added dark variants for outlined and text buttons ([#69](https://github.com/Just-Delivery/ui-components-web/issues/69)) ([79193df](https://github.com/Just-Delivery/ui-components-web/commit/79193df))
- changed justgarage to just-delivery ([362c2bc](https://github.com/Just-Delivery/ui-components-web/commit/362c2bc))
- Date error states ([#70](https://github.com/Just-Delivery/ui-components-web/issues/70)) ([b2797e4](https://github.com/Just-Delivery/ui-components-web/commit/b2797e4))
- Tailwind 1 migration ([#73](https://github.com/Just-Delivery/ui-components-web/issues/73)) ([1023ead](https://github.com/Just-Delivery/ui-components-web/commit/1023ead))

## [0.3.6](https://github.com/Just-Delivery/ui-components-web/compare/@justgarage/ui-components@0.3.5...@justgarage/ui-components@0.3.6) (2019-09-25)

### Bug Fixes

- changed build dist folder management to rimraf ([48523a0](https://github.com/Just-Delivery/ui-components-web/commit/48523a0))

## [0.3.5](https://github.com/Just-Delivery/ui-components-web/compare/@justgarage/ui-components@0.3.4...@justgarage/ui-components@0.3.5) (2019-09-25)

### Bug Fixes

- changed build dist folder management to rimraf ([994f7a7](https://github.com/Just-Delivery/ui-components-web/commit/994f7a7))

## [0.3.4](https://github.com/Just-Delivery/ui-components-web/compare/@justgarage/ui-components@0.3.3...@justgarage/ui-components@0.3.4) (2019-09-25)

### Bug Fixes

- changed build dist folder management to rimraf ([3f8c38d](https://github.com/Just-Delivery/ui-components-web/commit/3f8c38d))

## [0.3.3](https://github.com/Just-Delivery/ui-components-web/compare/@justgarage/ui-components@0.3.2...@justgarage/ui-components@0.3.3) (2019-09-25)

### Bug Fixes

- added fullstop ([cd98903](https://github.com/Just-Delivery/ui-components-web/commit/cd98903))

## [0.3.2](https://github.com/Just-Delivery/ui-components-web/compare/@justgarage/ui-components@0.3.1...@justgarage/ui-components@0.3.2) (2019-09-24)

### Bug Fixes

- added background colors on components ([#74](https://github.com/Just-Delivery/ui-components-web/issues/74)) ([b25545e](https://github.com/Just-Delivery/ui-components-web/commit/b25545e))

## [0.3.1](https://github.com/Just-Delivery/ui-components-web/compare/@justgarage/ui-components@0.3.0...@justgarage/ui-components@0.3.1) (2019-09-17)

### Bug Fixes

- fixed invalid grid spacing property ([fbe42b4](https://github.com/Just-Delivery/ui-components-web/commit/fbe42b4))

# [0.3.0](https://github.com/Just-Delivery/ui-components-web/compare/@justgarage/ui-components@0.2.3...@justgarage/ui-components@0.3.0) (2019-09-17)

### Features

- Tailwind 1 migration ([#73](https://github.com/Just-Delivery/ui-components-web/issues/73)) ([1023ead](https://github.com/Just-Delivery/ui-components-web/commit/1023ead))

## [0.2.3](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.2.2...@justgarage/ui-components@0.2.3) (2019-06-02)

**Note:** Version bump only for package @justgarage/ui-components

## [0.2.2](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.2.1...@justgarage/ui-components@0.2.2) (2019-05-21)

**Note:** Version bump only for package @justgarage/ui-components

## [0.2.1](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.2.0...@justgarage/ui-components@0.2.1) (2019-05-13)

### Bug Fixes

- updated date component labels ([#71](https://github.com/JustGarage/ui-components-web/issues/71)) ([d0c5968](https://github.com/JustGarage/ui-components-web/commit/d0c5968))

# [0.2.0](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.1.0...@justgarage/ui-components@0.2.0) (2019-05-01)

### Features

- Date error states ([#70](https://github.com/JustGarage/ui-components-web/issues/70)) ([b2797e4](https://github.com/JustGarage/ui-components-web/commit/b2797e4))

# [0.1.0](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.24...@justgarage/ui-components@0.1.0) (2019-05-01)

### Features

- added dark variants for outlined and text buttons ([#69](https://github.com/JustGarage/ui-components-web/issues/69)) ([79193df](https://github.com/JustGarage/ui-components-web/commit/79193df))

## [0.0.24](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.23...@justgarage/ui-components@0.0.24) (2019-04-18)

### Bug Fixes

- added spacing to grid example ([#67](https://github.com/JustGarage/ui-components-web/issues/67)) ([644d05f](https://github.com/JustGarage/ui-components-web/commit/644d05f))

## [0.0.23](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.22...@justgarage/ui-components@0.0.23) (2019-04-17)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.22](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.21...@justgarage/ui-components@0.0.22) (2019-04-17)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.21](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.20...@justgarage/ui-components@0.0.21) (2019-04-17)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.20](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.19...@justgarage/ui-components@0.0.20) (2019-04-15)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.19](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.18...@justgarage/ui-components@0.0.19) (2019-04-11)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.18](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.17...@justgarage/ui-components@0.0.18) (2019-04-10)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.17](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.16...@justgarage/ui-components@0.0.17) (2019-04-09)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.16](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.15...@justgarage/ui-components@0.0.16) (2019-04-09)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.15](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.14...@justgarage/ui-components@0.0.15) (2019-04-09)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.14](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.13...@justgarage/ui-components@0.0.14) (2019-04-09)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.13](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.12...@justgarage/ui-components@0.0.13) (2019-04-04)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.12](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.11...@justgarage/ui-components@0.0.12) (2019-04-03)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.11](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.10...@justgarage/ui-components@0.0.11) (2019-04-02)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.10](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.9...@justgarage/ui-components@0.0.10) (2019-03-29)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.9](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.8...@justgarage/ui-components@0.0.9) (2019-03-29)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.8](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.7...@justgarage/ui-components@0.0.8) (2019-03-21)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.7](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.6...@justgarage/ui-components@0.0.7) (2019-03-13)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.6](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.4...@justgarage/ui-components@0.0.6) (2019-03-13)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.5](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.4...@justgarage/ui-components@0.0.5) (2019-03-13)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.4](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.3...@justgarage/ui-components@0.0.4) (2018-12-05)

**Note:** Version bump only for package @justgarage/ui-components

## [0.0.3](https://github.com/JustGarage/ui-components-web/compare/@justgarage/ui-components@0.0.2...@justgarage/ui-components@0.0.3) (2018-11-26)

### Bug Fixes

- removed commented out code ([7c0883d](https://github.com/JustGarage/ui-components-web/commit/7c0883d))
